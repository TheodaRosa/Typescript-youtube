let X: number, N: number;
let a: number;
let fim: string;

function repetir(): void {
    let s: string;
    console.log("Deseja repetir?[S/N]");
    s = prompt() || '';
    if (s.toUpperCase() !== 'S' && s.toUpperCase() !== 'N') {
        do {
            console.log("Por favor, digite um valor válido: ");
            s = prompt() || '';
        } while (s.toUpperCase() !== 'S' && s.toUpperCase() !== 'N');
    }
    fim = s.toUpperCase();
}

while (fim !== 'N' && fim !== 'n') {
    console.clear();
    console.log("Escreva um numero natural: ");
    a = parseFloat(prompt('')) || 0;
    N = a - 1;
    X = a;
    if (a >= 0) {
        if (a === 0 || a === 1) {
            console.log("O resultado é 1");
            repetir();
        }
        if (a > 1) {
            for (let i = a; i >= 2; i--) {
                process.stdout.write(i + " x ");
            }
            console.log("1 =");
            do {
                X *= N;
                N--;
            } while (N > 1);
            console.log(X);
            repetir();
        }
    }
}
